from setuptools import _install_setup_requires, setup, version
setup(name ="packageaadi",version ="0.1.1",
author ="aditya",description = "Wow",long_description = "This package is mainy for beginnner",
packages =['packageaadi'],
_install_requires=[])