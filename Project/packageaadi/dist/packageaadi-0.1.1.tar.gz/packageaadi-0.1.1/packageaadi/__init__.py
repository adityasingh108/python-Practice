def mainfun(string):
    return f"{string} this Package run scussefully"


#install wheel
#python setup.py bdist_wheel    